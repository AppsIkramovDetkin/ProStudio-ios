////
////  AuthManager.swift
////  ProStudio
////
////  Created by Hadevs on 18/11/2018.
////  Copyright © 2018 Nikita. All rights reserved.
////
//
//import Foundation
//import FirebaseAuth
//
//class AuthManager {
//    static let shared = AuthManager()
//    private init() {}
//    
//    func signIn(email: String) {
//        Auth.auth().signIn(withEmail: <#T##String#>, password: <#T##String#>, completion: <#T##AuthDataResultCallback?##AuthDataResultCallback?##(AuthDataResult?, Error?) -> Void#>)
//    }
//}
