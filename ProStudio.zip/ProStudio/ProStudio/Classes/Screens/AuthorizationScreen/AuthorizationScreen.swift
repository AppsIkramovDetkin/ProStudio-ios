import UIKit
import FirebaseAuth
import Alamofire

class AuthorizationScreen: UIViewController {
	
	@IBOutlet weak var loginButton: CustomButton!
	@IBOutlet weak var cancelButton: UIButton!
	@IBOutlet weak var logoImage: UIImageView!
	@IBOutlet weak var passwordTextField: CustomTextField!
	@IBOutlet weak var emailTextField: CustomTextField!
	@IBOutlet weak var setAccessCodeLabel: UILabel!
	@IBOutlet weak var getLoginAndPasswordButton: UIButton!
	@IBOutlet weak var accessButton: UIButton!
	@IBOutlet weak var okImage: UIImageView!
	
	var setAccessButton: Bool = false
	
	override func viewDidLoad() {
		super.viewDidLoad()

		emailTextField.delegate = self
		passwordTextField.delegate = self
		hero.isEnabled = true
        logoImage.hero.id = "logo"
        loginButton.hero.id = "button"
		settingsView()
        emailTextField.font = PSFont.introRegular.with(size: 17)
        passwordTextField.font = PSFont.introRegular.with(size: 17)
        emailTextField.placeholderText = "Ваша почта"
        passwordTextField.placeholderText = "Пароль"
        getLoginAndPasswordButton.titleLabel?.font = PSFont.introRegular.with(size: 14.5)
        getLoginAndPasswordButton.setTitleColor(#colorLiteral(red: 0, green: 0.5156363845, blue: 0.8242413402, alpha: 1), for: .normal)
        getLoginAndPasswordButton.underline(with: #colorLiteral(red: 0, green: 0.5156363845, blue: 0.8242413402, alpha: 1))
        passwordTextField.underline()
        emailTextField.underline()
	}
	
	override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
		
	}

	func settingsView() {
		
		emailTextField.addTarget(self, action: #selector(editingBeganEmail(_:)), for: .editingDidBegin)
		emailTextField.addTarget(self, action: #selector(editingEndedEmail(_:)), for: .editingDidEnd)
		
		passwordTextField.addTarget(self, action: #selector(editingBeganPassword(_:)), for: .editingDidBegin)
		passwordTextField.addTarget(self, action: #selector(editingEndedPassword(_:)), for: .editingDidEnd)
		
		loginButton.setTitle("ВОЙТИ", for: .normal)
		
		cancelButton.setTitle("Отмена", for: .normal)
        cancelButton.addTarget(self, action: #selector(smartBack), for: .touchUpInside)
		cancelButton.titleLabel?.font = PSFont.cellText
		cancelButton.setTitleColor(PSColor.cerulean, for: .normal)
		
		logoImage.image = UIImage(named: "logo")
		
		setAccessCodeLabel.text = "Задать код доступа"
		setAccessCodeLabel.font = PSFont.cellText
		
		accessButton.backgroundColor = PSColors.light
		accessButton.layer.cornerRadius = 2
		accessButton.layer.masksToBounds = true
		
		
//    Если раскоментировать строки, то программа крашится
//		emailTextField.placeholderText = "Ваша почта"
//		passwordTextField.placeholderText = "Пароль"
		
	}
	
	@objc func editingBeganEmail(_ textField: UITextField) {
		emailTextField.chengeBorderColor()
	}
	
	@objc func editingEndedEmail(_ textField: UITextField) {
		emailTextField.chengeBorderColor()
	}
	
	@objc func editingBeganPassword(_ textField: UITextField) {
		passwordTextField.chengeBorderColor()
	}
	
	@objc func editingEndedPassword(_ textField: UITextField) {
		passwordTextField.chengeBorderColor()
	}
	
	@IBAction func login(_ sender: Any) {
        guard let email = emailTextField.text, let password = passwordTextField.text else {
            self.showAlert(title: "Ошибка", message: "Заполните поля")
            return
        }
        defaults.set(email, forKey: "email")
        defaults.set(password, forKey: "password")
        defaults.synchronize()
        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            if let _ = error {
                self.showAlert(title: "Ошибка", message: "Неверные данные")
            } else if let user = result?.user {
                currentUser = user
                if self.setAccessButton {
                    // need to set pin
                    let pinVC = SecurityScreen()
                    self.present(pinVC, animated: true, completion: nil)
                } else {
                    // no
                    let tabBarController = UITabBarController()
                    
                    //1.
                    let listVC = ProjectsList()
                    listVC.tabBarItem = UITabBarItem(title: "Проекты", image: UIImage.init(named: "projects"), tag: 0)
                    //2.
                    let cabinetVC = PersonalAccount()
                    let cabinetItem = UITabBarItem(title: "Кабинет", image: UIImage.init(named: "profile"), tag: 1)
                    let inset3: CGFloat = 0
                    cabinetItem.imageInsets = UIEdgeInsets(top: inset3, left: inset3, bottom: inset3, right: inset3)
                    cabinetVC.tabBarItem = cabinetItem
                    
                    //3.
                    let chatVC = UINavigationController(rootViewController: ChatWithManager())
                    let chatItem = UITabBarItem(title: "Поддержка", image: UIImage.init(named: "support"), tag: 2)
                    chatItem.imageInsets = UIEdgeInsets(top: inset3, left: inset3, bottom: inset3, right: inset3)
                    chatVC.tabBarItem = chatItem
                    //4.
                    let contactsVC = UINavigationController(rootViewController: ContactsViewController())
                    let contactsTabItem = UITabBarItem(title: "Контакты", image: UIImage.init(named: "contacts"), tag: 0)
                    let inset2: CGFloat = 0
                    contactsTabItem.imageInsets = UIEdgeInsets(top: inset2, left: inset2, bottom: inset2, right: inset2)
                    
                    contactsVC.tabBarItem = contactsTabItem
                    
                    tabBarController.tabBar.tintColor = PSColor.cerulean
                    tabBarController.tabBar.unselectedItemTintColor = PSColor.coolGrey
                    tabBarController.setViewControllers([listVC, chatVC, cabinetVC, contactsVC], animated: true)
                    self.present(tabBarController, animated: true, completion: nil)
                }
            }
        }
		
	}

	@IBAction func getLoginAndPasswordButton(_ sender: Any) {
        guard let email = emailTextField.text else {
            return
        }
        Auth.auth().fetchProviders(forEmail: email) { (string, error) in
            if let error = error {
                self.showAlert(title: "Ошибка", message: error.localizedDescription)
            } else {
                if string == nil {
                    let params: Parameters = [
                        "FromEmail": "hhadevs@gmail.com",
                        "FromName": "Prostudio",
                        "Subject": "Ваши данные для входа",
                        "Text-part": "ky-ky",
                        "Recipients": [["Email":"hhadevs@gmail.com"]]
                    ]
                    Alamofire.request("https://api.mailjet.com/v3/send", method: HTTPMethod.post, parameters: params).authenticate(user: "ee65626bfaf0d051a9bddd3f1b03a1d5", password: "e7e87174bf4342e2c4837383f0b286cc")
                        .responseString(completionHandler: { (string) in
                            print(string.result.value)
                        })
//                    Alamofire.request(<#T##url: URLConvertible##URLConvertible#>, method: HTTPM, parameters: <#T##Parameters?#>, encoding: <#T##ParameterEncoding#>, headers: <#T##HTTPHeaders?#>)
                    //todo: -> сделать восстановление
                } else {
                    self.showAlert(title: "Ошибка", message: "Данный email уже используется")
                }
            }
        }
	}
	
	@IBAction func accessButtonPressed(_ sender: Any) {
		
		if !setAccessButton {
			accessButton.backgroundColor = PSColor.cerulean
			okImage.image = UIImage(named: "invalid-name")
			setAccessButton = true
		} else {
			okImage.image = nil
			accessButton.backgroundColor = PSColors.light
			setAccessButton = false
		}
	}
}

extension AuthorizationScreen: UITextFieldDelegate {
	
	func textFieldShouldReturn(_ textField: UITextField) -> Bool {
		textField.resignFirstResponder()
		return true
	}
	
}

extension UIView {
    func underline(with color: UIColor = PSColors.light) {
        let line = UIView()
        line.translatesAutoresizingMaskIntoConstraints = false
        line.backgroundColor = color
        self.addSubview(line)
        line.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        line.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        line.topAnchor.constraint(equalTo: self.bottomAnchor, constant: -1).isActive = true
        line.heightAnchor.constraint(equalToConstant: 1.6).isActive = true
//        let constraints = NSLayoutConstraint.contraints(withNewVisualFormat: "H:|[v]|,V:[v(1)]|", dict: ["v": line])
        
//        self.addConstraints(constraints)
    }
}
